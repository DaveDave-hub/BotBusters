import flask

from flask import Flask, render_template
from twitterBot import get_factors, account_verification
app = Flask(__name__)

def likelihood(percentage):
    if percentage <= 15:
        return 'Not a bot'
    elif percentage > 15 and percentage <= 40:
        return 'Most likely not a bot'
    elif percentage > 40 and percentage <= 59:
        return 'Hard to verify'
    elif percentage > 59 and percentage <= 84:
        return 'Most likely bot'
    elif percentage > 84 and percentage <= 100:
        return 'Bot'

@app.route('/', methods=['GET', 'POST'])
def index():  # put application's code here
   return flask.render_template('MainPage.html')

@app.route('/verify', methods = ['GET', 'POST'])
def verify():
    handle = flask.request.form['handle']
    message_for_user = f'@{handle}'

    if get_factors(handle) == 'User not found':
        verification = f'User @{handle} not found'

    else:
        verdict = likelihood(account_verification(handle))
        verification = f' {account_verification(handle)}%'


    print(message_for_user)
    print(verdict)
    print(verification)

    return flask.render_template('MainPage.html', message_for_user=message_for_user, verdict=verdict,
                                 probability=verification)

if __name__ == '__main__':
    app.run()

